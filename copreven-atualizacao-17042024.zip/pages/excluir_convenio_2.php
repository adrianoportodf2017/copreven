<?php
include("../includes/autoload.php");
include("../header.php"); 

$registro = $_GET["registro"];
$sql = "DELETE FROM convenio WHERE id = '$registro'";
$resultado  = mysqli_query(connect(), "$sql");
mysqli_query(connect(), $sql);
mysqli_close(connect());

?>






  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h4>
          <font size="4" color="#00CC00"><span class="glyphicon glyphicon-minus" aria-hidden="true"></span></font>
          <font color="#FFFFFF">--</font><strong>ALTERAR OU EXCLUIR ATENDIMENTO</strong>
        </h4>
        <hr>



        <br>

        REGISTRO <strong><?php echo $registro; ?></strong> EXCLUÍDO COM SUCESSO !!


      </div>
      <hr>
    </div>



</body>

 <?php include("../footer.php"); ?>


</html>