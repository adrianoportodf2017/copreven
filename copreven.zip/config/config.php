
<?php
$banco = "copreven";
$usuario = "root";
$senha = "";
$hostname = "localhost";
$base_url = "http://localhost/copreven/";





?>